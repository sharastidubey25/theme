import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/network/api_client.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../router/app_router.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../data/auth_repository.dart';
import 'widgets/auth_scaffold.dart';

/// screens/auth/Register.js — creates the account via auth/login, then OTP.
class RegisterScreen extends ConsumerStatefulWidget {
  const RegisterScreen({super.key});

  @override
  ConsumerState<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends ConsumerState<RegisterScreen> {
  final _name = TextEditingController();
  final _mobile = TextEditingController();
  final _email = TextEditingController();
  final _firm = TextEditingController();
  final _partner = TextEditingController();
  AccountType _type = AccountType.individual;
  final _errors = <String, String?>{};
  bool _loading = false;

  @override
  void dispose() {
    for (final c in [_name, _mobile, _email, _firm, _partner]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    final errs = {
      'name': Validators.required(_name.text, 'Please enter your name'),
      'mobile': Validators.mobile(_mobile.text, empty: 'Please enter your mobile number'),
      'email': Validators.email(_email.text, empty: 'Please enter your email'),
      // RN requires the firm name for "firm" accounts only.
      'firm': _type == AccountType.firm ? Validators.required(_firm.text, 'Please enter your firm name') : null,
    };
    setState(() => _errors
      ..clear()
      ..addAll(errs));
    if (errs.values.any((e) => e != null)) return;

    FocusScope.of(context).unfocus();
    setState(() => _loading = true);
    try {
      final mobile = _mobile.text.trim();
      await ref.read(authRepositoryProvider).register(
            mobile: mobile,
            fullName: _name.text.trim(),
            email: _email.text.trim(),
            type: _type,
            firmName: _type == AccountType.individual ? '' : _firm.text.trim(),
            partnerCode: _type == AccountType.individual ? '' : _partner.text.trim(),
          );
      if (!mounted) return;
      context.push(Uri(path: Routes.otp, queryParameters: {'mobile': mobile}).toString());
    } on ApiException catch (e) {
      if (!mounted) return;
      // RN shows server messages under the mobile field.
      e.network ? showAuthError(context, e.message) : setState(() => _errors['mobile'] = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _clear(String key) {
    if (_errors[key] != null) setState(() => _errors[key] = null);
  }

  @override
  Widget build(BuildContext context) {
    final business = _type != AccountType.individual;
    return AuthScaffold(
      compact: true,
      child: AutofillGroup(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const AuthHeading(
            title: 'Create your account',
            subtitle: Text('Book repairs, track service tickets and shop — all in one place.'),
          ),
          const SizedBox(height: 24),
          AppTextField(
            label: 'Full name',
            controller: _name,
            hint: 'Your name',
            icon: Icons.person_outline_rounded,
            textCapitalization: TextCapitalization.words,
            autofillHints: const [AutofillHints.name],
            error: _errors['name'],
            onChanged: (_) => _clear('name'),
          ),
          const SizedBox(height: 16),
          AppTextField(
            label: 'Mobile number',
            controller: _mobile,
            hint: '98765 43210',
            prefixText: '+91',
            keyboardType: TextInputType.phone,
            digitsOnly: true,
            maxLength: 10,
            autofillHints: const [AutofillHints.telephoneNumberNational],
            error: _errors['mobile'],
            onChanged: (_) => _clear('mobile'),
          ),
          const SizedBox(height: 16),
          AppTextField(
            label: 'Email address',
            controller: _email,
            hint: 'you@example.com',
            icon: Icons.mail_outline_rounded,
            keyboardType: TextInputType.emailAddress,
            autofillHints: const [AutofillHints.email],
            textInputAction: business ? TextInputAction.next : TextInputAction.done,
            error: _errors['email'],
            onChanged: (_) => _clear('email'),
          ),
          const SizedBox(height: 16),
          _TypeDropdown(value: _type, onChanged: (t) => setState(() => _type = t)),
          AnimatedSize(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            child: business
                ? Column(children: [
                    const SizedBox(height: 16),
                    AppTextField(
                      label: _type == AccountType.firm ? 'Firm / business name' : 'Organisation name',
                      controller: _firm,
                      hint: _type == AccountType.firm ? 'e.g. Sharma Traders' : 'e.g. District Office',
                      icon: Icons.apartment_rounded,
                      textCapitalization: TextCapitalization.words,
                      autofillHints: const [AutofillHints.organizationName],
                      error: _errors['firm'],
                      onChanged: (_) => _clear('firm'),
                    ),
                    const SizedBox(height: 16),
                    AppTextField(
                      label: 'Partner code (optional)',
                      controller: _partner,
                      hint: 'If a FixPapa partner referred you',
                      icon: Icons.confirmation_number_outlined,
                      textInputAction: TextInputAction.done,
                    ),
                  ])
                : const SizedBox(width: double.infinity),
          ),
          const SizedBox(height: 28),
          AppButton(label: 'Register now', trailingArrow: true, expand: true, loading: _loading, onPressed: _submit),
          const SizedBox(height: 20),
          Wrap(alignment: WrapAlignment.center, crossAxisAlignment: WrapCrossAlignment.center, children: [
            Text('Already have an account? ', style: AppText.body(13.5, color: AppColors.ink3)),
            InkWell(
              borderRadius: BorderRadius.circular(6),
              // Register is usually opened from Login; go back instead of stacking another Login.
              onTap: () => context.canPop() ? context.pop() : context.pushReplacement(Routes.login),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 4),
                child: Text('Log in', style: AppText.head(13.5, weight: FontWeight.w700, color: AppColors.primary)),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

/// Customer type — a field like the others that opens a bottom-sheet list
/// (same options as the RN dropdown).
class _TypeDropdown extends StatelessWidget {
  const _TypeDropdown({required this.value, required this.onChanged});
  final AccountType value;
  final ValueChanged<AccountType> onChanged;

  static const icons = {
    AccountType.individual: Icons.person_outline_rounded,
    AccountType.firm: Icons.storefront_outlined,
    AccountType.government: Icons.account_balance_outlined,
  };

  Future<void> _open(BuildContext context) async {
    final picked = await showModalBottomSheet<AccountType>(
      context: context,
      backgroundColor: AppColors.white,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (sheet) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
              child: Text('Select customer type', style: AppText.h3),
            ),
            for (final t in AccountType.values)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Material(
                  color: t == value ? AppColors.primarySoft : AppColors.gray2,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    side: BorderSide(color: t == value ? AppColors.primary : Colors.transparent, width: 1.5),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    onTap: () => Navigator.pop(sheet, t),
                    child: SizedBox(
                      height: 56,
                      child: Row(children: [
                        const SizedBox(width: 16),
                        Icon(icons[t], size: 20, color: t == value ? AppColors.primary : AppColors.ink3),
                        const SizedBox(width: 12),
                        Expanded(child: Text(t.label, style: AppText.body(15, weight: FontWeight.w600, color: AppColors.ink))),
                        if (t == value) const Icon(Icons.check_circle_rounded, color: AppColors.primary, size: 22),
                        const SizedBox(width: 16),
                      ]),
                    ),
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
    if (picked != null) onChanged(picked);
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Customer type', style: AppText.label),
      const SizedBox(height: 8),
      Material(
        color: AppColors.gray2,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.md),
          onTap: () => _open(context),
          child: SizedBox(
            height: 56,
            child: Row(children: [
              const SizedBox(width: 16),
              Icon(icons[value], size: 20, color: AppColors.ink3),
              const SizedBox(width: 12),
              Expanded(child: Text(value.label, style: AppText.body(15, weight: FontWeight.w500, color: AppColors.ink))),
              const Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: AppColors.ink3),
              const SizedBox(width: 14),
            ]),
          ),
        ),
      ),
    ]);
  }
}
