import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/network/api_client.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../router/app_router.dart';
import '../../../shared/widgets/app_button.dart';
import '../../../shared/widgets/app_text_field.dart';
import '../data/auth_repository.dart';
import 'widgets/auth_scaffold.dart';

/// screens/auth/Login.js — mobile number → send OTP → OTP screen.
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _mobile = TextEditingController();
  String? _error;
  bool _loading = false;

  @override
  void dispose() {
    _mobile.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final err = Validators.mobile(_mobile.text);
    if (err != null) return setState(() => _error = err);
    FocusScope.of(context).unfocus();
    setState(() => _loading = true);
    try {
      final mobile = _mobile.text.trim();
      await ref.read(authRepositoryProvider).sendOtp(mobile);
      if (!mounted) return;
      context.push(Uri(path: Routes.otp, queryParameters: {'mobile': mobile}).toString());
    } on ApiException catch (e) {
      if (!mounted) return;
      e.network ? showAuthError(context, e.message) : setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      child: AutofillGroup(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const AuthHeading(
            title: 'Welcome back',
            subtitle: Text('Enter your registered mobile number to continue.'),
          ),
          const SizedBox(height: 28),
          AppTextField(
            label: 'Mobile number',
            controller: _mobile,
            hint: '98765 43210',
            prefixText: '+91',
            keyboardType: TextInputType.phone,
            digitsOnly: true,
            maxLength: 10,
            autofillHints: const [AutofillHints.telephoneNumberNational],
            textInputAction: TextInputAction.done,
            error: _error,
            onChanged: (_) => _error == null ? null : setState(() => _error = null),
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: 24),
          AppButton(label: 'Login with OTP', trailingArrow: true, expand: true, loading: _loading, onPressed: _submit),
          const SizedBox(height: 22),
          const OrDivider(),
          const SizedBox(height: 22),
          AppButton(
            label: 'Register now',
            variant: AppButtonVariant.ghost,
            icon: Icons.person_add_alt_1_rounded,
            expand: true,
            onPressed: () => context.push(Routes.register),
          ),
          const SizedBox(height: 28),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.lock_outline_rounded, size: 15, color: AppColors.ink3),
            const SizedBox(width: 6),
            Flexible(
              child: Text("We'll text a 6-digit code to verify it's you.",
                  textAlign: TextAlign.center, style: AppText.body(12.5, color: AppColors.ink3)),
            ),
          ]),
        ]),
      ),
    );
  }
}
