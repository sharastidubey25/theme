import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../router/app_router.dart';

/// Shared frame for Login / OTP / Register: dark hero with the brand,
/// then a white sheet that rises over it with the form.
class AuthScaffold extends StatelessWidget {
  const AuthScaffold({super.key, required this.child, this.compact = false});
  final Widget child;

  /// Smaller hero (no tagline) for the longer Register form.
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final top = mq.padding.top;
    final heroH = top + (compact ? 170.0 : 268.0);
    const overlap = 28.0;
    // Sheet fills the rest of the screen and grows with the form (scrolls with the keyboard).
    final sheetMin = (mq.size.height - heroH + overlap).clamp(0.0, double.infinity);

    return Scaffold(
      backgroundColor: AppColors.white,
      body: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          _Hero(topInset: top, compact: compact, height: heroH),
          Transform.translate(
            offset: const Offset(0, -overlap),
            child: Container(
              constraints: BoxConstraints(minHeight: sheetMin),
              decoration: const BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(overlap)),
              ),
              padding: EdgeInsets.fromLTRB(24, 32, 24, 24 + mq.padding.bottom),
              child: child,
            ),
          ),
        ]),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  const _Hero({required this.topInset, required this.compact, required this.height});
  final double topInset;
  final bool compact;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: const BoxDecoration(gradient: AppColors.gradDark),
      child: Stack(clipBehavior: Clip.hardEdge, children: [
        // Orange radar rings — same motif as the home service-centre card
        Positioned(
          right: -90,
          top: topInset - 70,
          child: SizedBox(
            width: 280,
            height: 280,
            child: Stack(alignment: Alignment.center, children: [
              for (final f in [1.0, .74, .48])
                Container(
                  width: 280 * f,
                  height: 280 * f,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: AppColors.primary2.withValues(alpha: .22)),
                    color: AppColors.primary2.withValues(alpha: .035),
                  ),
                ),
            ]),
          ),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(20, topInset + 10, 20, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            _BackButton(),
            const Spacer(),
            Image.asset('assets/images/logo-white.png', height: 32, filterQuality: FilterQuality.high),
            if (!compact) ...[
              const SizedBox(height: 18),
              Text.rich(
                const TextSpan(children: [
                  TextSpan(text: 'Healthy devices.\n'),
                  TextSpan(text: 'Happier business.', style: TextStyle(color: AppColors.primary2)),
                ]),
                style: AppText.head(26, color: Colors.white, height: 1.15),
              ),
            ],
            const SizedBox(height: 48),
          ]),
        ),
      ]),
    );
  }
}

class _BackButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white.withValues(alpha: .1),
        shape: CircleBorder(side: BorderSide(color: Colors.white.withValues(alpha: .14))),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () => context.canPop() ? context.pop() : context.go(Routes.home),
          child: const SizedBox(width: 40, height: 40, child: Icon(Icons.arrow_back_rounded, color: Colors.white, size: 20)),
        ),
      );
}

/// Title + subtitle block at the top of the white sheet.
class AuthHeading extends StatelessWidget {
  const AuthHeading({super.key, required this.title, required this.subtitle});
  final String title;
  final Widget subtitle;

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: AppText.head(26)),
        const SizedBox(height: 8),
        DefaultTextStyle(style: AppText.body(14.5, color: AppColors.ink3), child: subtitle),
      ]);
}

/// "──── or ────"
class OrDivider extends StatelessWidget {
  const OrDivider({super.key});

  @override
  Widget build(BuildContext context) => Row(children: [
        const Expanded(child: Divider(color: AppColors.border, height: 1)),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text('OR', style: AppText.mono(11, color: AppColors.ink3)),
        ),
        const Expanded(child: Divider(color: AppColors.border, height: 1)),
      ]);
}

/// Server/network error — floating snackbar in the brand style.
void showAuthError(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.navy,
      margin: const EdgeInsets.all(AppSpace.lg),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
      content: Row(children: [
        const Icon(Icons.error_outline_rounded, color: AppColors.primary3, size: 20),
        const SizedBox(width: 10),
        Expanded(child: Text(message, style: AppText.body(13.5, color: Colors.white))),
      ]),
    ));
}
