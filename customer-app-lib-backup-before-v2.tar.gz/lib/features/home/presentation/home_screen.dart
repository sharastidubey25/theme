import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/session/session_controller.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../router/app_router.dart';
import '../../../shared/models/product.dart';
import '../data/home_repository.dart';
import 'widgets/hero_banner_carousel.dart';
import 'widgets/home_header.dart';
import 'widgets/home_sections.dart';
import 'widgets/product_rail.dart';

/// Home — same sections and order as screens/home/Home.js, redesigned.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _refresh(WidgetRef ref) async {
    ref
      ..invalidate(bannersProvider)
      ..invalidate(highlightedServicesProvider)
      ..invalidate(homeProductsProvider)
      ..invalidate(testimonialsProvider);
    await ref.read(homeProductsProvider('').future).catchError((_) => <Product>[]);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    const gap = SliverToBoxAdapter(child: SizedBox(height: 36));
    final loggedIn = ref.watch(isLoggedInProvider);

    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () => _refresh(ref),
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
            slivers: [
              HomeHeader(loggedIn: loggedIn),
              const SliverToBoxAdapter(child: _SearchField()),
              const SliverToBoxAdapter(child: HeroBannerCarousel()),
              const SliverToBoxAdapter(child: SizedBox(height: 28)),
              SliverToBoxAdapter(child: BookRepairCard(loggedIn: loggedIn)),
              const SliverToBoxAdapter(
                child: Padding(padding: EdgeInsets.only(top: 20), child: HeroBannerCarousel(bannerType: 'service', hideWhileLoading: true)),
              ),
              gap,
              const SliverToBoxAdapter(
                child: ProductRail(
                  type: '',
                  listType: 'deal_of_the_day',
                  listTitle: 'Deal of the day',
                  eyebrow: 'Limited time',
                  title: 'Deal of the',
                  highlight: 'day',
                  subtitle: 'Offers closing soon',
                ),
              ),
              gap,
              const SliverToBoxAdapter(child: ShopByCategory()),
              gap,
              const SliverToBoxAdapter(child: TechSupportCard()),
              gap,
              SliverToBoxAdapter(
                child: ProductRail(
                  type: 'refurbished',
                  listType: 'refurbished',
                  listTitle: 'Refurbished',
                  eyebrow: 'Certified pre-owned',
                  title: 'Refurbished',
                  highlightBuilder: (items) {
                    if (items.isEmpty) return null;
                    final max = items.map((p) => p.discountPercent).reduce((a, b) => a > b ? a : b);
                    return max > 0 ? '· up to ${max.round()}% off' : null;
                  },
                ),
              ),
              gap,
              const SliverToBoxAdapter(child: PromoCarousel()),
              gap,
              const SliverToBoxAdapter(child: RentSection()),
              gap,
              const SliverToBoxAdapter(
                child: ProductRail(
                  type: 'new',
                  listType: 'new',
                  listTitle: 'Product On Sale',
                  eyebrow: 'Fresh arrivals',
                  title: 'New',
                  highlight: 'products',
                ),
              ),
              gap,
              const SliverToBoxAdapter(child: EwasteCard()),
              gap,
              const SliverToBoxAdapter(child: TestimonialsRail()),
              gap,
              const SliverToBoxAdapter(child: ServiceCenterCard()),
              const SliverToBoxAdapter(child: SizedBox(height: 32)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Tap-target styled as a search field; opens SearchProduct.
class _SearchField extends StatelessWidget {
  const _SearchField();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(AppSpace.gutter, 16, AppSpace.gutter, 18),
      child: Material(
        color: AppColors.gray2,
        shape: const StadiumBorder(),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: () => context.push(Routes.searchProduct),
          child: SizedBox(
            height: 50,
            child: Row(children: [
              const SizedBox(width: 18),
              const Icon(Icons.search_rounded, color: AppColors.ink3, size: 22),
              const SizedBox(width: 10),
              Expanded(child: Text('Search laptops, printers, ink…', style: AppText.body(14.5, color: AppColors.ink3))),
            ]),
          ),
        ),
      ),
    );
  }
}
