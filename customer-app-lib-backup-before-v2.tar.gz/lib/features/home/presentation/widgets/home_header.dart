import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../router/app_router.dart';

/// Pinned header: menu · logo · cart · login (Header.js on the home tab).
class HomeHeader extends StatelessWidget {
  const HomeHeader({super.key, this.cartCount = 0, this.loggedIn = false});
  final int cartCount;
  final bool loggedIn;

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      toolbarHeight: 64,
      backgroundColor: AppColors.white,
      surfaceTintColor: Colors.transparent,
      automaticallyImplyLeading: false,
      titleSpacing: 20,
      shape: const Border(bottom: BorderSide(color: AppColors.border)),
      title: Row(
        children: [
          _CircleBtn(icon: Icons.menu_rounded, tooltip: 'Menu', onTap: () => context.push(Routes.menu)),
          const SizedBox(width: 12),
          Image.asset('assets/images/logo.png', height: 24, filterQuality: FilterQuality.high),
          const Spacer(),
          _CircleBtn(
            icon: Icons.shopping_bag_outlined,
            tooltip: 'Cart',
            badge: cartCount,
            onTap: () => context.push(loggedIn ? Routes.cart : Routes.login),
          ),
          const SizedBox(width: 8),
          if (loggedIn)
            _CircleBtn(icon: Icons.person_outline_rounded, tooltip: 'Account', onTap: () => context.push(Routes.menu))
          else
            _LoginPill(onTap: () => context.push(Routes.login)),
        ],
      ),
    );
  }
}

class _CircleBtn extends StatelessWidget {
  const _CircleBtn({required this.icon, required this.tooltip, required this.onTap, this.badge = 0});
  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Stack(clipBehavior: Clip.none, children: [
        Material(
          color: AppColors.gray2,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(width: 40, height: 40, child: Icon(icon, size: 21, color: AppColors.ink)),
          ),
        ),
        if (badge > 0)
          Positioned(
            right: -2,
            top: -2,
            child: Container(
              constraints: const BoxConstraints(minWidth: 18),
              height: 18,
              padding: const EdgeInsets.symmetric(horizontal: 5),
              decoration: BoxDecoration(
                gradient: AppColors.gradPrimary,
                borderRadius: BorderRadius.circular(999),
                border: Border.all(color: Colors.white, width: 2),
              ),
              alignment: Alignment.center,
              child: Text('$badge', style: AppText.body(9.5, weight: FontWeight.w700, color: Colors.white, height: 1)),
            ),
          ),
      ]),
    );
  }
}

class _LoginPill extends StatelessWidget {
  const _LoginPill({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.navy,
      shape: const StadiumBorder(),
      child: InkWell(
        customBorder: const StadiumBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 16, 10),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.login_rounded, size: 17, color: Colors.white),
            const SizedBox(width: 6),
            Text('Login', style: AppText.head(13.5, weight: FontWeight.w700, color: Colors.white, height: 1)),
          ]),
        ),
      ),
    );
  }
}
