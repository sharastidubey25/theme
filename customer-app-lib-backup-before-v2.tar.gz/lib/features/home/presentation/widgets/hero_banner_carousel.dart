import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../shared/widgets/net_image.dart';
import '../../data/home_repository.dart';

/// Auto-advancing banner slider fed by master/site-banners.
class HeroBannerCarousel extends ConsumerStatefulWidget {
  const HeroBannerCarousel({super.key, this.bannerType = 'banner', this.hideWhileLoading = false});
  final String bannerType;
  final bool hideWhileLoading;

  @override
  ConsumerState<HeroBannerCarousel> createState() => _HeroBannerCarouselState();
}

class _HeroBannerCarouselState extends ConsumerState<HeroBannerCarousel> {
  static const _aspect = 840 / 340; // CDN *-mobile.png banners
  final _ctrl = PageController(viewportFraction: .9);
  Timer? _timer;
  int _index = 0;
  int _count = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (_count < 2 || !_ctrl.hasClients) return;
      _ctrl.animateToPage((_index + 1) % _count, duration: const Duration(milliseconds: 600), curve: Curves.easeOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final banners = ref.watch(bannersProvider(widget.bannerType));
    final width = MediaQuery.sizeOf(context).width * .9 - 12;
    final height = width / _aspect;

    return banners.when(
      loading: () => widget.hideWhileLoading ? const SizedBox.shrink() : _frame(height, const ColoredBox(color: AppColors.gray2)),
      error: (_, _) => const SizedBox.shrink(),
      data: (list) {
        _count = list.length;
        if (list.isEmpty) return const SizedBox.shrink();
        return Column(children: [
          SizedBox(
            height: height,
            child: PageView.builder(
              controller: _ctrl,
              itemCount: list.length,
              onPageChanged: (i) => setState(() => _index = i),
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Semantics(
                  label: list[i].alt.replaceAll('-', ' '),
                  image: true,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.lg - 4),
                    child: NetImage(list[i].image),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < list.length; i++)
                AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: i == _index ? 20 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: i == _index ? AppColors.primary : AppColors.borderStrong,
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
            ],
          ),
        ]);
      },
    );
  }

  Widget _frame(double h, Widget child) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: ClipRRect(borderRadius: BorderRadius.circular(AppRadius.lg - 4), child: SizedBox(height: h, width: double.infinity, child: child)),
      );
}
