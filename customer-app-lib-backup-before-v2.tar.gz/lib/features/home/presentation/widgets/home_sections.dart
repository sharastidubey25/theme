import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../router/app_router.dart';
import '../../../../shared/widgets/app_button.dart';
import '../../../../shared/widgets/login_required_sheet.dart';
import '../../../../shared/widgets/net_image.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../data/home_repository.dart';

const _gutter = EdgeInsets.symmetric(horizontal: AppSpace.gutter);

/// Shared rounded photo with a dark scrim, used by the promo cards.
class _PhotoScrim extends StatelessWidget {
  const _PhotoScrim({required this.asset, this.begin = Alignment.centerLeft, this.end = Alignment.centerRight, this.strong = .92});
  final String asset;
  final Alignment begin;
  final Alignment end;
  final double strong;

  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        Image.asset(asset, fit: BoxFit.cover),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: begin,
              end: end,
              colors: [AppColors.navy.withValues(alpha: strong), AppColors.navy.withValues(alpha: strong * .55), AppColors.navy.withValues(alpha: .05)],
              stops: const [0, .55, 1],
            ),
          ),
        ),
      ]);
}

// ─────────────────────────────────────────────── Book a Repair (BookARepair.js)

class BookRepairCard extends ConsumerWidget {
  const BookRepairCard({super.key, required this.loggedIn});
  final bool loggedIn;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final services = ref.watch(highlightedServicesProvider);

    return Padding(
      padding: _gutter,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: DecoratedBox(
          decoration: const BoxDecoration(gradient: AppColors.gradDark),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Hero part with photo on the right
              // Grows with text scale; 236 is the design height.
              LayoutBuilder(builder: (context, c) => ConstrainedBox(
                constraints: BoxConstraints(minHeight: 236, minWidth: c.maxWidth),
                child: Stack(fit: StackFit.passthrough, children: [
                  Positioned(
                    right: 0,
                    top: 0,
                    bottom: 0,
                    width: c.maxWidth * .5,
                    child: Stack(fit: StackFit.expand, children: [
                      Image.asset('assets/images/photo-repair.jpg', fit: BoxFit.cover, alignment: const Alignment(.25, 0)),
                      const DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [AppColors.navy, Color(0x990B1220), Color(0x000B1220)],
                            stops: [0, .45, 1],
                          ),
                        ),
                      ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const Eyebrow('Repair · Doorstep', dark: true),
                        const SizedBox(height: 12),
                        Text.rich(
                          const TextSpan(children: [
                            TextSpan(text: 'Book a\n'),
                            TextSpan(text: 'Repair', style: TextStyle(color: AppColors.primary2)),
                          ]),
                          style: AppText.head(32, color: Colors.white, height: 1.05),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: c.maxWidth * .56,
                          child: Text(
                            'Comprehensive repair for a wide range of brands, all under one roof.',
                            style: AppText.body(13, color: Colors.white.withValues(alpha: .72)),
                          ),
                        ),
                        const SizedBox(height: 22),
                        AppButton(
                          label: 'Book now',
                          trailingArrow: true,
                          size: AppButtonSize.sm,
                          onPressed: () => context.go(Routes.bookARepair),
                        ),
                      ],
                    ),
                  ),
                ]),
              )),
              Container(height: 1, margin: const EdgeInsets.symmetric(horizontal: 20), color: Colors.white.withValues(alpha: .08)),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text.rich(
                      const TextSpan(children: [
                        TextSpan(text: 'Frequently booked '),
                        TextSpan(text: 'services', style: TextStyle(color: AppColors.primary2)),
                      ]),
                      style: AppText.head(17, weight: FontWeight.w700, color: Colors.white),
                    ),
                    const SizedBox(height: 14),
                    services.when(
                      loading: () => _grid(List.generate(6, (_) => const _ServiceTile.skeleton())),
                      error: (_, _) => const SizedBox.shrink(),
                      data: (list) => _grid([
                        for (final s in list)
                          _ServiceTile(
                            label: s.name,
                            icon: s.icon,
                            onTap: () => loggedIn
                                ? context.push(Uri(path: Routes.selectBrand, queryParameters: {'productCategoryID': '${s.id}'}).toString())
                                : showLoginRequired(context),
                          ),
                      ]),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _grid(List<Widget> children) => LayoutBuilder(builder: (_, c) {
        const gap = 10.0;
        final w = (c.maxWidth - gap * 2) / 3;
        return Wrap(spacing: gap, runSpacing: gap, children: [for (final ch in children) SizedBox(width: w, child: ch)]);
      });
}

class _ServiceTile extends StatelessWidget {
  const _ServiceTile({required this.label, required this.icon, required this.onTap});
  const _ServiceTile.skeleton()
      : label = '',
        icon = '',
        onTap = null;
  final String label;
  final String icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withValues(alpha: .06),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadius.md),
        side: BorderSide(color: Colors.white.withValues(alpha: .09)),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.md),
        onTap: onTap,
        child: SizedBox(
          height: 96,
          child: label.isEmpty
              ? null
              : Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 10),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    SizedBox(width: 36, height: 36, child: NetImage(icon, fit: BoxFit.contain, background: Colors.transparent)),
                    const SizedBox(height: 10),
                    Text(label,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: AppText.body(11.5, weight: FontWeight.w500, color: Colors.white, height: 1.25)),
                  ]),
                ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────── Shop by category (Home.js grid)

class ShopByCategory extends StatelessWidget {
  const ShopByCategory({super.key});

  // (label, image, ProductList `category` param) — same values as Home.js
  static const _cats = [
    ('Laptop', 'assets/images/category-laptop.png', 'Laptop'),
    ('Desktop', 'assets/images/category-desktop.png', 'Desktops'),
    ('LED/LCD Monitor', 'assets/images/category-monitor.png', 'Monitor'),
    ('Rack & Tower Servers', 'assets/images/category-server.png', 'Servers'),
    ('CCTV', 'assets/images/category-cctv.png', 'cctv'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _gutter,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SectionHeader(eyebrow: 'Shop', title: 'Shop by', highlight: 'category'),
        const SizedBox(height: 16),
        LayoutBuilder(builder: (_, c) {
          const gap = 10.0;
          final w = (c.maxWidth - gap * 2) / 3;
          return Wrap(spacing: gap, runSpacing: gap, children: [
            for (final cat in _cats)
              SizedBox(
                width: w,
                child: _CategoryTile(
                  label: cat.$1,
                  image: cat.$2,
                  onTap: () => context.push(Uri(path: Routes.productList, queryParameters: {'category': cat.$3}).toString()),
                ),
              ),
            SizedBox(width: w, child: _ExploreTile(onTap: () => context.push(Routes.productList))),
          ]);
        }),
      ]),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.label, required this.image, required this.onTap});
  final String label;
  final String image;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          side: const BorderSide(color: AppColors.border),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.md),
          onTap: onTap,
          child: SizedBox(
            height: 112,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 12, 8, 10),
              child: Column(children: [
                Expanded(child: Image.asset(image, fit: BoxFit.contain)),
                const SizedBox(height: 8),
                Text(label,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    style: AppText.body(11.5, weight: FontWeight.w600, color: AppColors.ink, height: 1.2)),
              ]),
            ),
          ),
        ),
      );
}

class _ExploreTile extends StatelessWidget {
  const _ExploreTile({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(AppRadius.md),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppRadius.md),
          onTap: onTap,
          child: SizedBox(
            height: 112,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(gradient: AppColors.gradPrimary, shape: BoxShape.circle),
                  child: const Icon(Icons.arrow_outward_rounded, color: Colors.white, size: 18),
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.bottomLeft,
                      child: Text('Explore all\nproducts', style: AppText.head(13, weight: FontWeight.w700, color: Colors.white, height: 1.25)),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );
}

// ─────────────────────────────────────────────── Technical support (TechnicalSupport.js)

class TechSupportCard extends StatelessWidget {
  const TechSupportCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _gutter,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppRadius.lg),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: 244, minWidth: double.infinity),
          child: Stack(fit: StackFit.passthrough, children: [
            const Positioned.fill(child: _PhotoScrim(asset: 'assets/images/photo-support.jpg')),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Eyebrow('Technical support', dark: true),
                const SizedBox(height: 12),
                Text.rich(
                  const TextSpan(children: [
                    TextSpan(text: 'Fixed on a call,\nfrom '),
                    TextSpan(text: '₹5', style: TextStyle(color: AppColors.primary2)),
                  ]),
                  style: AppText.head(26, color: Colors.white, height: 1.12),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: 220,
                  child: Text('Skilled technicians help you install and configure a range of devices and systems.',
                      style: AppText.body(12.5, color: Colors.white.withValues(alpha: .75))),
                ),
                const SizedBox(height: 20),
                AppButton(
                  label: 'Know more',
                  size: AppButtonSize.sm,
                  variant: AppButtonVariant.light,
                  trailingArrow: true,
                  onPressed: () => context.push(Routes.technicalSupport),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────── Installation & AMC promos (Home.js horizontal scroll)

class PromoCarousel extends StatelessWidget {
  const PromoCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      (
        'Installation',
        'Seamless setup for your technology',
        'assets/images/photo-tech.jpg',
        () => context.push(Routes.bookAnInstallation),
      ),
      (
        'AMC packages',
        'Exclusive discounts on non-comprehensive IT support',
        'assets/images/photo-amc.jpg',
        () => context.go(Routes.amc),
      ),
    ];
    return SizedBox(
      height: 184,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: _gutter,
        physics: const BouncingScrollPhysics(),
        itemCount: items.length,
        separatorBuilder: (_, _) => const SizedBox(width: 12),
        itemBuilder: (_, i) {
          final it = items[i];
          return SizedBox(
            width: MediaQuery.sizeOf(context).width * .8,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(AppRadius.lg - 4),
              child: Material(
                color: AppColors.navy,
                child: InkWell(
                  onTap: it.$4,
                  child: Stack(fit: StackFit.expand, children: [
                    _PhotoScrim(asset: it.$3, begin: Alignment.bottomLeft, end: Alignment.topRight, strong: .95),
                    Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Eyebrow(it.$1, dark: true),
                        const Spacer(),
                        Text(it.$2, maxLines: 2, style: AppText.head(19, color: Colors.white, height: 1.2)),
                        const SizedBox(height: 10),
                        Row(children: [
                          Text('Know more', style: AppText.head(13, weight: FontWeight.w700, color: AppColors.primary3)),
                          const SizedBox(width: 4),
                          const Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.primary3),
                        ]),
                      ]),
                    ),
                  ]),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────── Rental (Rental.js)

class RentSection extends StatelessWidget {
  const RentSection({super.key});

  static const _items = [
    ('Desktop', 'assets/images/photo-desktop.jpg', 'desktop'),
    ('Printer', 'assets/images/photo-printer.jpg', 'printer'),
    ('Laptop', 'assets/images/photo-laptops.jpg', 'laptop'),
    ('Projector', 'assets/images/photo-projector.jpg', 'projector'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _gutter,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(gradient: AppColors.gradDark, borderRadius: BorderRadius.circular(AppRadius.lg)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SectionHeader(
            eyebrow: 'Rental',
            title: 'Why buy when you can',
            highlight: 'rent?',
            subtitle: 'A huge collection of IT gadgets, available on rent.',
            dark: true,
          ),
          const SizedBox(height: 18),
          LayoutBuilder(builder: (_, c) {
            const gap = 10.0;
            final w = (c.maxWidth - gap) / 2;
            return Wrap(spacing: gap, runSpacing: gap, children: [
              for (final it in _items)
                SizedBox(
                  width: w,
                  height: w * .82,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    child: Material(
                      child: InkWell(
                        onTap: () => context.push(Uri(path: Routes.rentalList, queryParameters: {'category': it.$3}).toString()),
                        child: Stack(fit: StackFit.expand, children: [
                          _PhotoScrim(asset: it.$2, begin: Alignment.bottomCenter, end: Alignment.topCenter, strong: .9),
                          Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
                              Text('RENT', style: AppText.eyebrow(color: AppColors.primary3)),
                              const SizedBox(height: 2),
                              Row(children: [
                                Expanded(child: Text(it.$1, style: AppText.head(16, weight: FontWeight.w700, color: Colors.white))),
                                const Icon(Icons.arrow_forward_rounded, size: 18, color: Colors.white),
                              ]),
                            ]),
                          ),
                        ]),
                      ),
                    ),
                  ),
                ),
            ]);
          }),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────── E-waste (EWaste.js)

class EwasteCard extends StatelessWidget {
  const EwasteCard({super.key});

  static const _green = AppColors.green;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _gutter,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: const Color(0xFFF0FDF4),
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: const Color(0xFFD1FADF)),
        ),
        child: Stack(children: [
          Positioned(
            right: -30,
            bottom: -20,
            width: 190,
            height: 190,
            child: Opacity(
              opacity: .9,
              child: ClipOval(child: Image.asset('assets/images/photo-ewaste.jpg', fit: BoxFit.cover)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Eyebrow('Sustainability', color: _green),
              const SizedBox(height: 12),
              Text.rich(
                const TextSpan(children: [
                  TextSpan(text: 'Unlock value from\nyour '),
                  TextSpan(text: 'e-waste', style: TextStyle(color: _green)),
                ]),
                style: AppText.head(24, height: 1.15),
              ),
              const SizedBox(height: 8),
              FractionallySizedBox(
                widthFactor: .58,
                child: Text('Responsible e-waste management, made easy. Sell and benefit while you contribute to a sustainable future.',
                    style: AppText.body(13, color: AppColors.ink3)),
              ),
              const SizedBox(height: 20),
              Material(
                color: _green,
                shape: const StadiumBorder(),
                child: InkWell(
                  customBorder: const StadiumBorder(),
                  onTap: () => context.go(Routes.ewaste),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.recycling_rounded, size: 18, color: Colors.white),
                      const SizedBox(width: 8),
                      Text('Sell your e-waste', style: AppText.head(13.5, weight: FontWeight.w700, color: Colors.white, height: 1)),
                    ]),
                  ),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────── Testimonials (ClientTestimonial.js)

class TestimonialsRail extends ConsumerWidget {
  const TestimonialsRail({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(testimonialsProvider);
    final list = async.value ?? const [];
    if (async.hasValue && list.isEmpty || async.hasError) return const SizedBox.shrink();

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Padding(
        padding: _gutter,
        child: SectionHeader(eyebrow: 'Testimonials', title: 'Few words from our', highlight: 'clients'),
      ),
      const SizedBox(height: 16),
      SizedBox(
        height: 196,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: _gutter,
          physics: const BouncingScrollPhysics(),
          itemCount: async.isLoading ? 3 : list.length,
          separatorBuilder: (_, _) => const SizedBox(width: 12),
          itemBuilder: (_, i) {
            if (async.isLoading) {
              return Container(
                width: 232,
                height: 132,
                alignment: Alignment.topCenter,
                decoration: BoxDecoration(color: AppColors.gray2, borderRadius: BorderRadius.circular(AppRadius.md)),
              );
            }
            final t = list[i];
            return SizedBox(
              width: 232,
              child: InkWell(
                borderRadius: BorderRadius.circular(AppRadius.md),
                onTap: () {
                  final uri = Uri.tryParse(t.videoUrl);
                  if (uri != null) launchUrl(uri, mode: LaunchMode.externalApplication);
                },
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(AppRadius.md),
                    child: SizedBox(
                      height: 132,
                      width: double.infinity,
                      child: Stack(fit: StackFit.expand, children: [
                        NetImage(t.thumbnail),
                        const DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0x990B1220)]),
                          ),
                        ),
                        Center(
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: AppShadows.md),
                            child: const Icon(Icons.play_arrow_rounded, color: AppColors.primary, size: 28),
                          ),
                        ),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(t.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: AppText.body(13, weight: FontWeight.w600, color: AppColors.ink, height: 1.35)),
                  const SizedBox(height: 2),
                  Text(t.by, style: AppText.mono(10.5)),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }
}

// ─────────────────────────────────────────────── Service centre (ServiceCenter.js)

/// Finder-style card: radar + pin motif, search field, brand logos.
class ServiceCenterCard extends StatelessWidget {
  const ServiceCenterCard({super.key});

  static const _brands = ['hp', 'dell', 'lenovo', 'epson', 'brother', 'acer'];

  @override
  Widget build(BuildContext context) {
    void open() => context.push(Routes.serviceCenter);

    return Padding(
      padding: _gutter,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.white, AppColors.primarySoft],
          ),
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: AppColors.border),
          boxShadow: AppShadows.sm,
        ),
        child: Stack(children: [
          const Positioned(right: -70, top: -70, child: _Radar(size: 240)),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Eyebrow('Service centres'),
              const SizedBox(height: 12),
              Text.rich(
                const TextSpan(children: [
                  TextSpan(text: 'Got into '),
                  TextSpan(text: 'trouble?', style: TextStyle(color: AppColors.primary)),
                ]),
                style: AppText.head(26, height: 1.1),
              ),
              const SizedBox(height: 6),
              Text('Find an authorised centre near you.', style: AppText.body(14, color: AppColors.ink3)),
              const SizedBox(height: 18),
              // Search-style entry point
              Material(
                color: AppColors.white,
                shape: const StadiumBorder(side: BorderSide(color: AppColors.border)),
                child: InkWell(
                  customBorder: const StadiumBorder(),
                  onTap: open,
                  child: SizedBox(
                    height: 52,
                    child: Row(children: [
                      const SizedBox(width: 16),
                      const Icon(Icons.search_rounded, size: 21, color: AppColors.ink3),
                      const SizedBox(width: 10),
                      Expanded(child: Text('Search by brand or city', style: AppText.body(14, color: AppColors.ink3))),
                      Container(
                        width: 42,
                        height: 42,
                        margin: const EdgeInsets.only(right: 5),
                        decoration: const BoxDecoration(gradient: AppColors.gradPrimary, shape: BoxShape.circle),
                        child: const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 20),
                      ),
                    ]),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              // Brand strip
              InkWell(
                onTap: open,
                borderRadius: BorderRadius.circular(AppRadius.sm),
                child: Row(children: [
                  SizedBox(
                    height: 38,
                    width: 30.0 * _brands.length + 8,
                    child: Stack(children: [
                      for (var i = 0; i < _brands.length; i++)
                        Positioned(left: i * 30.0, child: _BrandDot(_brands[i])),
                    ]),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text.rich(
                      TextSpan(children: [
                        TextSpan(text: '100+ brands', style: AppText.body(13, weight: FontWeight.w700, color: AppColors.ink)),
                        TextSpan(text: '\nacross India', style: AppText.body(12, color: AppColors.ink3)),
                      ]),
                      style: const TextStyle(height: 1.3),
                    ),
                  ),
                ]),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _BrandDot extends StatelessWidget {
  const _BrandDot(this.brand);
  final String brand;

  @override
  Widget build(BuildContext context) => Container(
        width: 38,
        height: 38,
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: AppColors.white,
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.border, width: 1.5),
          boxShadow: const [BoxShadow(color: Color(0x140F172A), blurRadius: 6, offset: Offset(0, 2))],
        ),
        child: SvgPicture.asset('assets/images/brands/$brand.svg', semanticsLabel: brand),
      );
}

/// Concentric rings with a location pin — the "locator" motif.
class _Radar extends StatelessWidget {
  const _Radar({required this.size});
  final double size;

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: Stack(alignment: Alignment.center, children: [
          for (final f in [1.0, .72, .44])
            Container(
              width: size * f,
              height: size * f,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.primary.withValues(alpha: .14)),
                color: AppColors.primary.withValues(alpha: .03),
              ),
            ),
          Transform.translate(
            offset: const Offset(0, -4),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(gradient: AppColors.gradPrimary, shape: BoxShape.circle, boxShadow: AppShadows.glow),
              child: const Icon(Icons.location_on_rounded, color: Colors.white, size: 24),
            ),
          ),
        ]),
      );
}
