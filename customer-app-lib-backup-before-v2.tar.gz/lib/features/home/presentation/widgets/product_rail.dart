import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/session/session_controller.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/theme/app_tokens.dart';
import '../../../../router/app_router.dart';
import '../../../../shared/models/product.dart';
import '../../../../shared/widgets/product_card.dart';
import '../../../../shared/widgets/section_header.dart';
import '../../data/home_repository.dart';

/// Horizontal product rail (DealOfTheDay.js / Refurbished.js / ProductSale.js).
class ProductRail extends ConsumerWidget {
  const ProductRail({
    super.key,
    required this.type,
    required this.listType,
    required this.listTitle,
    required this.eyebrow,
    required this.title,
    this.highlight,
    this.subtitle,
    this.highlightBuilder,
  });

  /// `type` filter for product/all-products.
  final String type;

  /// `type` passed to the ProductList screen on "View all".
  final String listType;
  final String listTitle;
  final String eyebrow;
  final String title;
  final String? highlight;
  final String? subtitle;

  /// Optional dynamic highlight computed from loaded products.
  final String? Function(List<Product>)? highlightBuilder;

  static const _cardW = 172.0;
  static const _railH = 312.0;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(homeProductsProvider(type));
    final loggedIn = ref.watch(isLoggedInProvider);
    if (async.hasValue && async.value!.isEmpty) return const SizedBox.shrink();

    final hl = async.hasValue && highlightBuilder != null ? highlightBuilder!(async.value!) ?? highlight : highlight;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpace.gutter),
          child: SectionHeader(
            eyebrow: eyebrow,
            title: title,
            highlight: hl,
            subtitle: subtitle,
            onViewAll: () => context.push(Uri(path: Routes.productList, queryParameters: {'type': listType, 'title': listTitle}).toString()),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: _railH,
          child: async.when(
            loading: () => _list(6, (_) => const _CardSkeleton()),
            error: (e, _) => _RailError(onRetry: () => ref.invalidate(homeProductsProvider(type))),
            data: (items) => _list(
              items.length,
              (i) => ProductCard(
                width: _cardW,
                product: items[i],
                onTap: () => context.push(Uri(path: Routes.productDetail, queryParameters: {'id': '${items[i].id}', 'slug': items[i].slug}).toString()),
                // Cart & wishlist need a session (ProductCard.js sends guests to Login).
                // TODO(cart): call add-to-cart / wishlist APIs when the Cart screen is migrated.
                onAddToCart: () => context.push(loggedIn ? Routes.cart : Routes.login),
                onWishlist: () => context.push(loggedIn ? Routes.cart : Routes.login),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _list(int n, Widget Function(int) item) => ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: AppSpace.gutter),
        physics: const BouncingScrollPhysics(),
        itemCount: n,
        separatorBuilder: (_, _) => const SizedBox(width: 12),
        itemBuilder: (_, i) => Align(alignment: Alignment.topCenter, child: item(i)),
      );
}

class _CardSkeleton extends StatelessWidget {
  const _CardSkeleton();

  @override
  Widget build(BuildContext context) {
    Widget bar(double w, double h) =>
        Container(width: w, height: h, decoration: BoxDecoration(color: AppColors.gray2, borderRadius: BorderRadius.circular(6)));
    return Container(
      width: ProductRail._cardW,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(AppRadius.lg - 4),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        AspectRatio(aspectRatio: 1, child: bar(double.infinity, double.infinity)),
        const SizedBox(height: 12),
        bar(60, 10),
        const SizedBox(height: 8),
        bar(140, 12),
        const SizedBox(height: 6),
        bar(100, 12),
        const SizedBox(height: 16),
        bar(80, 16),
        const SizedBox(height: 8),
      ]),
    );
  }
}

class _RailError extends StatelessWidget {
  const _RailError({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSpace.gutter),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(color: AppColors.gray2, borderRadius: BorderRadius.circular(AppRadius.lg - 4)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off_rounded, color: AppColors.ink3),
            const SizedBox(height: 8),
            Text("Couldn't load products", style: AppText.bodyM),
            TextButton(onPressed: onRetry, child: Text('Try again', style: AppText.head(14, weight: FontWeight.w700, color: AppColors.primary))),
          ]),
        ),
      );
}
