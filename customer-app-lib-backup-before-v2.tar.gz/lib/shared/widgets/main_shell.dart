import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_theme.dart';

/// Bottom tab shell — same four tabs as BottomNav.js.
class MainShell extends StatelessWidget {
  const MainShell({super.key, required this.shell});
  final StatefulNavigationShell shell;

  static const _tabs = [
    (Icons.grid_view_rounded, Icons.grid_view_outlined, 'Home'),
    (Icons.build_circle_rounded, Icons.build_circle_outlined, 'Book Repair'),
    (Icons.recycling_rounded, Icons.recycling_outlined, 'E-Waste'),
    (Icons.verified_user_rounded, Icons.verified_user_outlined, 'AMC'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: shell,
      bottomNavigationBar: DecoratedBox(
        decoration: const BoxDecoration(
          color: AppColors.white,
          border: Border(top: BorderSide(color: AppColors.border)),
          boxShadow: [BoxShadow(color: Color(0x0F0F172A), blurRadius: 24, offset: Offset(0, -8))],
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 64,
            child: Row(
              children: [
                for (var i = 0; i < _tabs.length; i++)
                  Expanded(
                    child: _TabItem(
                      active: shell.currentIndex == i,
                      icon: _tabs[i].$1,
                      inactiveIcon: _tabs[i].$2,
                      label: _tabs[i].$3,
                      onTap: () => shell.goBranch(i, initialLocation: i == shell.currentIndex),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TabItem extends StatelessWidget {
  const _TabItem({required this.active, required this.icon, required this.inactiveIcon, required this.label, required this.onTap});
  final bool active;
  final IconData icon;
  final IconData inactiveIcon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkResponse(
      onTap: onTap,
      radius: 40,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOut,
            width: 52,
            height: 30,
            decoration: BoxDecoration(
              color: active ? AppColors.primarySoft : Colors.transparent,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Icon(active ? icon : inactiveIcon, size: 22, color: active ? AppColors.primary : AppColors.ink3),
          ),
          const SizedBox(height: 4),
          Text(label,
              style: AppText.head(11.5, weight: active ? FontWeight.w700 : FontWeight.w600, color: active ? AppColors.ink : AppColors.ink3)),
        ],
      ),
    );
  }
}
