import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../features/auth/presentation/login_screen.dart';
import '../features/auth/presentation/otp_screen.dart';
import '../features/auth/presentation/register_screen.dart';
import '../features/home/presentation/home_screen.dart';
import '../shared/widgets/main_shell.dart';
import '../shared/widgets/pending_screen.dart';

/// Paths mirror the React Native stack names (app/routes/index.js) so each
/// `navigation.navigate('X', params)` ports to `context.push(Routes.x, ...)`.
/// Screens not yet redesigned resolve to [PendingScreen].
abstract final class Routes {
  // Bottom tabs
  static const home = '/';
  static const bookARepair = '/book-a-repair';
  static const ewaste = '/ewaste';
  static const amc = '/amc';

  // Pushed screens
  static const menu = '/menu';
  static const login = '/login';
  static const register = '/register';
  static const otp = '/otp';
  static const cart = '/cart';
  static const searchProduct = '/search';
  static const productList = '/products';
  static const productDetail = '/product';
  static const selectBrand = '/book-a-repair/brand';
  static const bookAnInstallation = '/book-an-installation';
  static const technicalSupport = '/technical-support';
  static const rentalList = '/rental';
  static const serviceCenter = '/service-centers';
}

final _rootKey = GlobalKey<NavigatorState>();

GoRoute _pending(String path, String title) => GoRoute(
      path: path,
      parentNavigatorKey: _rootKey,
      builder: (_, s) => PendingScreen(title: title, params: s.uri.queryParameters),
    );

final appRouter = GoRouter(
  navigatorKey: _rootKey,
  initialLocation: Routes.home,
  routes: [
    StatefulShellRoute.indexedStack(
      builder: (_, _, shell) => MainShell(shell: shell),
      branches: [
        StatefulShellBranch(routes: [GoRoute(path: Routes.home, builder: (_, _) => const HomeScreen())]),
        StatefulShellBranch(routes: [
          GoRoute(path: Routes.bookARepair, builder: (_, _) => const PendingScreen(title: 'Book a Repair', inShell: true)),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: Routes.ewaste, builder: (_, _) => const PendingScreen(title: 'E-Waste', inShell: true)),
        ]),
        StatefulShellBranch(routes: [
          GoRoute(path: Routes.amc, builder: (_, _) => const PendingScreen(title: 'AMC', inShell: true)),
        ]),
      ],
    ),
    _pending(Routes.menu, 'Menu'),
    GoRoute(path: Routes.login, parentNavigatorKey: _rootKey, builder: (_, _) => const LoginScreen()),
    GoRoute(path: Routes.register, parentNavigatorKey: _rootKey, builder: (_, _) => const RegisterScreen()),
    GoRoute(
      path: Routes.otp,
      parentNavigatorKey: _rootKey,
      builder: (_, s) => OtpScreen(mobile: s.uri.queryParameters['mobile'] ?? ''),
    ),
    _pending(Routes.cart, 'Cart'),
    _pending(Routes.searchProduct, 'Search'),
    _pending(Routes.productList, 'Products'),
    _pending(Routes.productDetail, 'Product Detail'),
    _pending(Routes.selectBrand, 'Select Brand'),
    _pending(Routes.bookAnInstallation, 'Book an Installation'),
    _pending(Routes.technicalSupport, 'Technical Support'),
    _pending(Routes.rentalList, 'Rental'),
    _pending(Routes.serviceCenter, 'Service Centers'),
  ],
);
